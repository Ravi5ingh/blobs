﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.IO;
using System.Windows.Forms;
using Spire.PdfViewer.Forms;
using Spire.Pdf;
using Spire.Pdf.Annotations;
using Spire.Pdf.Attachments;
using Spire.Pdf.Graphics;
using Spire.Pdf.Security;


namespace ViewPDF
{
    public partial class Form1 : Form
    {
        private bool m_isAttachmentAnnotation;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CreatePDF();
            this.listView1.Visible = false;
            this.tableLayoutPanel1.SetRowSpan(this.pdfDocumentViewer1, 2);
            if (File.Exists(@"..\..\ViewPDF.pdf"))
            {
                this.pdfDocumentViewer1.LoadFromFile(@"..\..\ViewPDF.pdf", "e-iceblue");
            }
        }
        /// <summary>
        /// Open PDF document
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "PDF document(*.pdf)|*.pdf";
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                string pdfFile = dialog.FileName;
                this.pdfDocumentViewer1.LoadFromFile(pdfFile);
            }
        }

        private void CreatePDF()
        {
            //Create a pdf document.
            PdfDocument doc = new PdfDocument();

            //margin
            PdfUnitConvertor unitCvtr = new PdfUnitConvertor();
            PdfMargins margin = new PdfMargins();
            margin.Top = unitCvtr.ConvertUnits(2.54f, PdfGraphicsUnit.Centimeter, PdfGraphicsUnit.Point);
            margin.Bottom = margin.Top;
            margin.Left = unitCvtr.ConvertUnits(3.17f, PdfGraphicsUnit.Centimeter, PdfGraphicsUnit.Point);
            margin.Right = margin.Left;

            //create section
            PdfSection section = doc.Sections.Add();
            section.PageSettings.Size = PdfPageSize.A4;
            section.PageSettings.Margins = margin;

            // Create one page
            PdfPageBase page = section.Pages.Add();

            float y = 30;

            //attachment
            PdfAttachment attachment = new PdfAttachment("Header.png");
            attachment.Data = File.ReadAllBytes(@"..\..\Header.png");
            attachment.Description = "Page header picture of demo.";
            attachment.MimeType = "image/png";
            doc.Attachments.Add(attachment);

            PdfTrueTypeFont font2 = new PdfTrueTypeFont(new Font("Arial", 12f, FontStyle.Bold));
            PointF location = new PointF(0, y);
            String label = "Sales Report Chart";
            byte[] data = File.ReadAllBytes(@"..\..\SalesReportChart.png");
            SizeF size = font2.MeasureString(label);
            RectangleF bounds = new RectangleF(location, size);
            page.Canvas.DrawString(label, font2, PdfBrushes.Green, bounds);
            bounds = new RectangleF(bounds.Right + 3, bounds.Top, font2.Height / 2, font2.Height);
            PdfAttachmentAnnotation annotation1
                = new PdfAttachmentAnnotation(bounds, "SalesReportChart.png", data);
            annotation1.Color = Color.Teal;
            annotation1.Flags = PdfAnnotationFlags.ReadOnly;
            annotation1.Icon = PdfAttachmentIcon.Graph;
            annotation1.Text = "Sales Report Chart";
            (page as PdfNewPage).Annotations.Add(annotation1);
            y = y + size.Height + 20;

            float x = 0;
            PdfTrueTypeFont font = new PdfTrueTypeFont(new Font("Arial", 12));
            String labelLink = "Hyperlinks: ";
            PdfStringFormat format = new PdfStringFormat();
            format.MeasureTrailingSpaces = true;
            page.Canvas.DrawString(labelLink, font, PdfBrushes.Green, 0, y, format);
            x = font.MeasureString(labelLink, format).Width;
            PdfTrueTypeFont font1 = new PdfTrueTypeFont(new Font("Arial", 12, FontStyle.Underline));
            String url1 = "http://www.e-iceblue.com";
            page.Canvas.DrawString(url1, font1, PdfBrushes.Blue, x, y);
            y = y + 20;

            //true type font - embedded.
            System.Drawing.Font Emfont = new System.Drawing.Font("Arial", 14f, FontStyle.Bold);
            PdfTrueTypeFont trueTypeFont = new PdfTrueTypeFont(Emfont);
            page.Canvas.DrawString("Font Family: Arial - Embedded", trueTypeFont, PdfBrushes.Green, 0, (y = y + 16f));

            y = y + 20;
            //true type font - not embedded
            Emfont = new System.Drawing.Font("Batang", 14f, FontStyle.Italic);
            trueTypeFont = new PdfTrueTypeFont(Emfont);
            page.Canvas.DrawString("Font Family: Batang - Not Embedded", trueTypeFont, PdfBrushes.Green, 0, (y = y + 16f));

            //encrypt
            doc.Security.Encrypt("e-iceblue", "e-iceblue", PdfPermissionsFlags.Print | PdfPermissionsFlags.FillFields, PdfEncryptionKeySize.Key256Bit);

            doc.SaveToFile(@"..\..\ViewPDF.pdf");
            doc.Close();

        }

        /// <summary>
        /// Read PDF document common attachments
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAttachment_Click(object sender, EventArgs e)
        {
            this.tableLayoutPanel1.SetRowSpan(this.pdfDocumentViewer1, 1);
            this.m_isAttachmentAnnotation = false;
            this.listView1.Visible = true;
            this.listView1.Columns.Clear();
            this.listView1.Items.Clear();
            if (this.pdfDocumentViewer1.IsDocumentLoaded)
            {
                //Get common attachment in PDF document
                PdfDocumentAttachment[] attchments = this.pdfDocumentViewer1.GetAttachments();
                this.listView1.View = View.Details;
                this.listView1.Columns.Add("FileName",80);
                this.listView1.Columns.Add("MimeType",80);
                this.listView1.Columns.Add("Description",120);
                this.listView1.Columns.Add("CreationTime",100);
                this.listView1.Columns.Add("ModifyTime",100);
                if (attchments != null && attchments.Length > 0)
                {
                    //get common attachment property
                    for (int i = 0; i < attchments.Length; i++)
                    {
                        PdfDocumentAttachment attachment = attchments[i];
                        string fileName = attachment.FileName;
                        string mimeType = attachment.MimeType;
                        string desc = attachment.Description;
                        DateTime createDate = attachment.CreationTime;
                        DateTime modifyDate = attachment.ModifyTime;
                        Object data = attachment.Data;
                        ListViewItem item = new ListViewItem();
                        item.Text = Path.GetFileName(fileName);
                        item.SubItems.Add(mimeType);
                        item.SubItems.Add(desc);
                        item.SubItems.Add(createDate.ToShortDateString());
                        item.SubItems.Add(modifyDate.ToShortDateString());
                        item.Tag = attachment;
                        this.listView1.Items.Add(item);
                    }
                }
            }
        }
        /// <summary>
        /// Read PDF document attachment annotation 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAttachmentAnnotation_Click(object sender, EventArgs e)
        {
            this.tableLayoutPanel1.SetRowSpan(this.pdfDocumentViewer1, 1);
            this.m_isAttachmentAnnotation = true;
            this.listView1.Visible = true;
            this.listView1.Items.Clear();
            this.listView1.Columns.Clear();
            if (this.pdfDocumentViewer1.IsDocumentLoaded && this.pdfDocumentViewer1.PageCount > 0)
            {
                this.listView1.View = View.Details;
                this.listView1.Columns.Add("FileName",200);
                this.listView1.Columns.Add("Text",180);
                this.listView1.Columns.Add("PageIndex",80);
                this.listView1.Columns.Add("Location",160);
                //Get attachment annotations in PDF document
                PdfDocumentAttachmentAnnotation[] annotations = this.pdfDocumentViewer1.GetAttachmentAnnotaions();
                if (annotations != null && annotations.Length > 0)
                {
                    //read attachment annotation property
                    for (int i = 0; i < annotations.Length; i++)
                    {
                        PdfDocumentAttachmentAnnotation annotation = annotations[i];
                        ListViewItem item = new ListViewItem(annotation.FileName);
                        item.SubItems.Add(annotation.Text);
                        item.SubItems.Add(annotation.PageIndex.ToString());
                        item.SubItems.Add(annotation.Location.ToString());
                        item.Tag = annotation;
                        this.listView1.Items.Add(item);
                    }
                }

            }
        }
        /// <summary>
        /// Go to Specified attachment annotation
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listView1_Click(object sender, EventArgs e)
        {
            if (this.m_isAttachmentAnnotation)
            {
                PdfDocumentAttachmentAnnotation annotation = (PdfDocumentAttachmentAnnotation)this.listView1.SelectedItems[0].Tag;
                this.pdfDocumentViewer1.GotoAttachmentAnnotation(annotation);
            }
        }
        /// <summary>
        /// Export PDF document attachment
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            ListViewItem item = this.listView1.SelectedItems[0];
            SaveFileDialog dialog = new SaveFileDialog();
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                string fileName = dialog.FileName;
                FileStream stream = new FileStream(fileName, FileMode.Create);
                BinaryWriter writer = new BinaryWriter(stream);
                if (this.m_isAttachmentAnnotation)
                {
                    PdfDocumentAttachmentAnnotation annotation = (PdfDocumentAttachmentAnnotation)item.Tag;
                    byte[] data = annotation.Data;
                    writer.Write(data);
                }
                else
                {
                    PdfDocumentAttachment annotation = (PdfDocumentAttachment)item.Tag;
                    byte[] data = annotation.Data;
                    writer.Write(data);
                }

                writer.Close();
                stream.Close();
                System.Diagnostics.Process.Start(fileName);
               
            }
        }

        private void BtnCloseAttachment_Click(object sender, EventArgs e)
        {
            this.listView1.Visible = false;
            this.tableLayoutPanel1.SetRowSpan(this.pdfDocumentViewer1, 2);
        }


    }
}
